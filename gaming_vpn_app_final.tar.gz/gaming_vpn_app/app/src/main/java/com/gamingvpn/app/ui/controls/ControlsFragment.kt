package com.gamingvpn.app.ui.controls

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.gamingvpn.app.databinding.FragmentControlsBinding
import com.gamingvpn.app.controls.GameControlsOverlayService

class ControlsFragment : Fragment() {

    private var _binding: FragmentControlsBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var controlsViewModel: ControlsViewModel
    private lateinit var gamesAdapter: GamesAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        controlsViewModel = ViewModelProvider(this)[ControlsViewModel::class.java]

        _binding = FragmentControlsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupUI()
        observeViewModel()

        return root
    }
    
    private fun setupUI() {
        // Setup RecyclerView for games list
        gamesAdapter = GamesAdapter { game ->
            onGameSelected(game)
        }
        
        binding.gamesRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = gamesAdapter
        }
        
        // Add game button
        binding.addGameButton.setOnClickListener {
            showAddGameDialog()
        }
        
        // Control editor area
        setupControlEditor()
    }
    
    private fun observeViewModel() {
        controlsViewModel.games.observe(viewLifecycleOwner) { games ->
            gamesAdapter.submitList(games)
        }
        
        controlsViewModel.selectedGame.observe(viewLifecycleOwner) { game ->
            if (game != null) {
                loadControlsForGame(game)
            }
        }
    }
    
    private fun onGameSelected(game: Game) {
        controlsViewModel.selectGame(game)
        
        // Enable controls overlay for this game
        val intent = Intent(requireContext(), GameControlsOverlayService::class.java)
        intent.action = "ENABLE_CONTROLS"
        intent.putExtra("game_profile", game.profile)
        requireContext().startService(intent)
    }
    
    private fun showAddGameDialog() {
        // In a real implementation, this would show a dialog to add a new game
        val newGame = Game(
            id = System.currentTimeMillis().toString(),
            name = "New Game ${controlsViewModel.games.value?.size ?: 0 + 1}",
            profile = "default",
            icon = "ic_gamepad"
        )
        controlsViewModel.addGame(newGame)
    }
    
    private fun setupControlEditor() {
        // Setup the drag-and-drop control editor
        binding.controlEditorArea.setOnDragListener { _, event ->
            // Handle drag and drop events for control buttons
            true
        }
        
        // Add control buttons to the editor
        addControlButtonsToEditor()
    }
    
    private fun addControlButtonsToEditor() {
        // Add draggable control buttons
        val buttons = listOf("A", "B", "X", "Y", "D-Pad", "Joystick")
        
        for (button in buttons) {
            val buttonView = createDraggableButton(button)
            binding.controlButtonsContainer.addView(buttonView)
        }
    }
    
    private fun createDraggableButton(buttonName: String): View {
        val button = LayoutInflater.from(requireContext())
            .inflate(com.gamingvpn.app.R.layout.draggable_control_button, null)
        
        // Set button text and make it draggable
        button.setOnLongClickListener {
            // Start drag operation
            true
        }
        
        return button
    }
    
    private fun loadControlsForGame(game: Game) {
        // Load saved control layout for the selected game
        binding.gameNameText.text = game.name
        
        // Clear existing controls in editor
        binding.controlEditorArea.removeAllViews()
        
        // Load saved control positions for this game
        // This would typically load from a database or shared preferences
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

data class Game(
    val id: String,
    val name: String,
    val profile: String,
    val icon: String
)

