package com.gamingvpn.app.ui.translation

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TranslationViewModel : ViewModel() {

    private val _translationEnabled = MutableLiveData<Boolean>().apply {
        value = false
    }
    val translationEnabled: LiveData<Boolean> = _translationEnabled
    
    private val _targetLanguage = MutableLiveData<String>().apply {
        value = "العربية"
    }
    val targetLanguage: LiveData<String> = _targetLanguage
    
    private val _fontSize = MutableLiveData<Int>().apply {
        value = 50 // Default font size (0-100 scale)
    }
    val fontSize: LiveData<Int> = _fontSize
    
    private val _overlayOpacity = MutableLiveData<Int>().apply {
        value = 80 // Default opacity (0-100 scale)
    }
    val overlayOpacity: LiveData<Int> = _overlayOpacity
    
    fun setTranslationEnabled(enabled: Boolean) {
        _translationEnabled.value = enabled
    }
    
    fun setTargetLanguage(language: String) {
        _targetLanguage.value = language
    }
    
    fun setFontSize(size: Int) {
        _fontSize.value = size
    }
    
    fun setOverlayOpacity(opacity: Int) {
        _overlayOpacity.value = opacity
    }
}

