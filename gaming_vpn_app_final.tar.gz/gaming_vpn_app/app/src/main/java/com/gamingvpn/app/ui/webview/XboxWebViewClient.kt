package com.gamingvpn.app.ui.webview

import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.util.Log

class XboxWebViewClient : WebViewClient() {
    
    companion object {
        private const val TAG = "XboxWebViewClient"
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val url = request?.url?.toString()
        Log.d(TAG, "Loading URL: $url")
        
        // Allow Xbox Cloud Gaming URLs
        if (url?.contains("xbox.com") == true || 
            url?.contains("xboxlive.com") == true ||
            url?.contains("microsoft.com") == true) {
            return false // Let WebView handle it
        }
        
        return super.shouldOverrideUrlLoading(view, request)
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        Log.d(TAG, "Page finished loading: $url")
        
        // Inject custom JavaScript for Better xCloud functionality
        view?.evaluateJavascript("""
            // Better xCloud enhancements
            (function() {
                // Hide unnecessary elements
                const style = document.createElement('style');
                style.textContent = `
                    /* Hide Xbox app promotion banner */
                    .AppPromotion { display: none !important; }
                    
                    /* Optimize for mobile gaming */
                    body { 
                        overflow: hidden !important; 
                        user-select: none !important;
                    }
                    
                    /* Improve touch controls */
                    .gamepad-button {
                        touch-action: manipulation !important;
                    }
                `;
                document.head.appendChild(style);
                
                // Optimize WebView performance
                if (window.performance && window.performance.mark) {
                    window.performance.mark('webview-optimized');
                }
                
                console.log('Better xCloud WebView optimizations applied');
            })();
        """.trimIndent()) { result ->
            Log.d(TAG, "JavaScript injection result: $result")
        }
    }

    override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
        super.onPageStarted(view, url, favicon)
        Log.d(TAG, "Page started loading: $url")
    }
}

