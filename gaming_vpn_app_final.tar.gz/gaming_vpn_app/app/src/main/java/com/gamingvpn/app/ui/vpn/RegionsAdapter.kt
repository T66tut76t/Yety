package com.gamingvpn.app.ui.vpn

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.gamingvpn.app.R

class RegionsAdapter(
    private val onRegionClick: (String) -> Unit
) : ListAdapter<String, RegionsAdapter.RegionViewHolder>(RegionDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RegionViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_region, parent, false)
        return RegionViewHolder(view)
    }

    override fun onBindViewHolder(holder: RegionViewHolder, position: Int) {
        val region = getItem(position)
        holder.bind(region, onRegionClick)
    }

    class RegionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val regionName: TextView = itemView.findViewById(R.id.region_name)
        private val regionFlag: ImageView = itemView.findViewById(R.id.region_flag)
        private val checkMark: ImageView = itemView.findViewById(R.id.check_mark)

        fun bind(region: String, onRegionClick: (String) -> Unit) {
            regionName.text = region
            
            // Set flag based on region (example, you would have more flags)
            val flagResource = when (region) {
                "United States" -> R.drawable.ic_flag_us
                "Germany" -> R.drawable.ic_flag_de
                "Singapore" -> R.drawable.ic_flag_sg
                "United Kingdom" -> R.drawable.ic_flag_uk
                "Canada" -> R.drawable.ic_flag_ca
                "Australia" -> R.drawable.ic_flag_au
                "Netherlands" -> R.drawable.ic_flag_nl
                "Japan" -> R.drawable.ic_flag_jp
                else -> R.drawable.ic_flag_us // Default flag
            }
            regionFlag.setImageResource(flagResource)
            
            // TODO: Implement logic to show/hide checkmark based on selected region
            checkMark.visibility = View.GONE

            itemView.setOnClickListener {
                onRegionClick(region)
            }
        }
    }

    class RegionDiffCallback : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem == newItem
        }
    }
}

