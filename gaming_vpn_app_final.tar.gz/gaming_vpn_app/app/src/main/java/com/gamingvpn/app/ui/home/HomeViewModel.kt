package com.gamingvpn.app.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    private val _vpnStatus = MutableLiveData<String>().apply {
        value = "Disconnected"
    }
    val vpnStatus: LiveData<String> = _vpnStatus
    
    private val _selectedRegion = MutableLiveData<String>().apply {
        value = "United States"
    }
    val selectedRegion: LiveData<String> = _selectedRegion
    
    private val _translationEnabled = MutableLiveData<Boolean>().apply {
        value = false
    }
    val translationEnabled: LiveData<Boolean> = _translationEnabled
    
    fun setVpnStatus(status: String) {
        _vpnStatus.value = status
    }
    
    fun setSelectedRegion(region: String) {
        _selectedRegion.value = region
    }
    
    fun setTranslationEnabled(enabled: Boolean) {
        _translationEnabled.value = enabled
    }
}

