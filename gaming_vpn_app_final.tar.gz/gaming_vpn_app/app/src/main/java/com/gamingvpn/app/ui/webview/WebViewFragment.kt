package com.gamingvpn.app.ui.webview

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.fragment.app.Fragment
import com.gamingvpn.app.databinding.FragmentWebviewBinding
import com.gamingvpn.app.utils.DeviceOptimizer
import com.gamingvpn.app.utils.PerformanceMonitor

class WebViewFragment : Fragment() {

    private var _binding: FragmentWebviewBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var deviceOptimizer: DeviceOptimizer
    private lateinit var performanceMonitor: PerformanceMonitor

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWebviewBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Initialize optimizers
        deviceOptimizer = DeviceOptimizer(requireContext())
        performanceMonitor = PerformanceMonitor(requireContext())

        val webView: WebView = binding.webview
        setupWebView(webView)

        return root
    }

    private fun setupWebView(webView: WebView) {
        webView.webViewClient = XboxWebViewClient()
        val webSettings: WebSettings = webView.settings
        
        // Get optimization settings for device
        val optimizationSettings = deviceOptimizer.optimizeForHuaweiY6Prime()
        
        // Apply device-specific optimizations
        deviceOptimizer.optimizeWebView(webView, optimizationSettings)
        
        // Enable JavaScript and DOM storage
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.databaseEnabled = true
        
        // Media settings for gaming
        webSettings.mediaPlaybackRequiresUserGesture = false
        webSettings.allowFileAccess = true
        webSettings.allowContentAccess = true
        
        // Display settings optimized for gaming
        webSettings.loadWithOverviewMode = true
        webSettings.useWideViewPort = true
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false
        webSettings.setSupportZoom(false)
        
        // Cache and performance settings
        webSettings.cacheMode = WebSettings.LOAD_DEFAULT
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        
        // Better xCloud specific settings optimized for Huawei Y6 Prime 2019
        webSettings.userAgentString = "Mozilla/5.0 (Linux; Android 9; DUB-LX1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36"
        
        // Hardware acceleration based on device capabilities
        if (optimizationSettings.enableHardwareAcceleration) {
            webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH)
        } else {
            webSettings.setRenderPriority(WebSettings.RenderPriority.NORMAL)
        }
        
        // Load Xbox Cloud Gaming URL
        webView.loadUrl("https://www.xbox.com/play")
        
        // Start performance monitoring
        performanceMonitor.startMonitoring()
    }
    
    override fun onResume() {
        super.onResume()
        performanceMonitor.startMonitoring()
    }
    
    override fun onPause() {
        super.onPause()
        performanceMonitor.stopMonitoring()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        performanceMonitor.stopMonitoring()
        _binding = null
    }
}

