package com.gamingvpn.app.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.gamingvpn.app.R

class GameControlButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    
    var buttonText: String = "A"
        set(value) {
            field = value
            invalidate()
        }
    
    var buttonType: ButtonType = ButtonType.ACTION
        set(value) {
            field = value
            invalidate()
        }
    
    var isPressed: Boolean = false
        set(value) {
            field = value
            invalidate()
        }
    
    var onButtonClickListener: (() -> Unit)? = null
    
    enum class ButtonType {
        ACTION,      // A, B, X, Y buttons
        DPAD,        // Directional pad
        JOYSTICK,    // Analog stick
        TRIGGER,     // L1, L2, R1, R2
        SPECIAL      // Menu, Options, etc.
    }
    
    init {
        setupPaint()
        isClickable = true
        isFocusable = true
    }
    
    private fun setupPaint() {
        paint.style = Paint.Style.FILL
        
        textPaint.style = Paint.Style.FILL
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.textSize = 48f
        textPaint.color = ContextCompat.getColor(context, R.color.text_primary)
        textPaint.isFakeBoldText = true
    }
    
    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        canvas ?: return
        
        val centerX = width / 2f
        val centerY = height / 2f
        val radius = minOf(width, height) / 2f - 10f
        
        // Draw button background
        paint.color = when {
            isPressed -> ContextCompat.getColor(context, R.color.accent_color_light)
            else -> ContextCompat.getColor(context, R.color.accent_color)
        }
        paint.alpha = if (isPressed) 255 else 180
        
        when (buttonType) {
            ButtonType.ACTION -> {
                // Draw circular button
                canvas.drawCircle(centerX, centerY, radius, paint)
                
                // Draw button text
                val textY = centerY + (textPaint.textSize / 3)
                canvas.drawText(buttonText, centerX, textY, textPaint)
            }
            
            ButtonType.DPAD -> {
                // Draw cross-shaped D-pad
                val thickness = radius / 3
                
                // Horizontal bar
                rect.set(centerX - radius, centerY - thickness, centerX + radius, centerY + thickness)
                canvas.drawRoundRect(rect, 10f, 10f, paint)
                
                // Vertical bar
                rect.set(centerX - thickness, centerY - radius, centerX + thickness, centerY + radius)
                canvas.drawRoundRect(rect, 10f, 10f, paint)
            }
            
            ButtonType.JOYSTICK -> {
                // Draw joystick base
                paint.alpha = 100
                canvas.drawCircle(centerX, centerY, radius, paint)
                
                // Draw joystick stick
                paint.alpha = 255
                canvas.drawCircle(centerX, centerY, radius * 0.4f, paint)
            }
            
            ButtonType.TRIGGER -> {
                // Draw rectangular trigger button
                rect.set(centerX - radius, centerY - radius * 0.6f, centerX + radius, centerY + radius * 0.6f)
                canvas.drawRoundRect(rect, 15f, 15f, paint)
                
                // Draw trigger text
                val textY = centerY + (textPaint.textSize / 4)
                canvas.drawText(buttonText, centerX, textY, textPaint)
            }
            
            ButtonType.SPECIAL -> {
                // Draw rounded rectangle for special buttons
                rect.set(centerX - radius, centerY - radius * 0.5f, centerX + radius, centerY + radius * 0.5f)
                canvas.drawRoundRect(rect, 20f, 20f, paint)
                
                // Draw text with smaller size
                textPaint.textSize = 32f
                val textY = centerY + (textPaint.textSize / 4)
                canvas.drawText(buttonText, centerX, textY, textPaint)
                textPaint.textSize = 48f // Reset
            }
        }
        
        // Draw border
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = ContextCompat.getColor(context, R.color.text_secondary)
        paint.alpha = 150
        
        when (buttonType) {
            ButtonType.ACTION, ButtonType.JOYSTICK -> {
                canvas.drawCircle(centerX, centerY, radius, paint)
            }
            ButtonType.DPAD -> {
                // Draw border for D-pad (simplified)
                canvas.drawCircle(centerX, centerY, radius, paint)
            }
            ButtonType.TRIGGER -> {
                rect.set(centerX - radius, centerY - radius * 0.6f, centerX + radius, centerY + radius * 0.6f)
                canvas.drawRoundRect(rect, 15f, 15f, paint)
            }
            ButtonType.SPECIAL -> {
                rect.set(centerX - radius, centerY - radius * 0.5f, centerX + radius, centerY + radius * 0.5f)
                canvas.drawRoundRect(rect, 20f, 20f, paint)
            }
        }
        
        paint.style = Paint.Style.FILL // Reset
    }
    
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        when (event?.action) {
            MotionEvent.ACTION_DOWN -> {
                isPressed = true
                onButtonClickListener?.invoke()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isPressed = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }
    
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredSize = when (buttonType) {
            ButtonType.ACTION -> 120
            ButtonType.DPAD -> 140
            ButtonType.JOYSTICK -> 160
            ButtonType.TRIGGER -> 100
            ButtonType.SPECIAL -> 80
        }
        
        val width = resolveSize(desiredSize, widthMeasureSpec)
        val height = resolveSize(desiredSize, heightMeasureSpec)
        
        setMeasuredDimension(width, height)
    }
}

