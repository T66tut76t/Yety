package com.gamingvpn.app.utils

import android.content.Context
import android.os.Build
import android.util.Log
import android.webkit.WebSettings
import android.webkit.WebView

class DeviceOptimizer(private val context: Context) {
    
    companion object {
        private const val TAG = "DeviceOptimizer"
        
        // Huawei Y6 Prime 2019 specifications
        private const val TARGET_DEVICE = "DUB-LX1"
        private const val TARGET_RAM_MB = 3072 // 3GB RAM
        private const val TARGET_API_LEVEL = 28 // Android 9
    }
    
    fun optimizeForHuaweiY6Prime(): OptimizationSettings {
        val settings = OptimizationSettings()
        
        // Check if running on target device
        val isTargetDevice = isHuaweiY6Prime()
        Log.d(TAG, "Is Huawei Y6 Prime 2019: $isTargetDevice")
        
        if (isTargetDevice || isLowEndDevice()) {
            // Apply optimizations for low-end devices
            settings.apply {
                webViewCacheSize = 50 * 1024 * 1024 // 50MB cache
                translationUpdateInterval = 3000 // 3 seconds
                controlsOpacity = 0.7f
                enableHardwareAcceleration = false
                maxConcurrentTranslations = 1
                useCompressedTextures = true
                reducedAnimations = true
                lowQualityOverlays = true
            }
        } else {
            // Standard settings for better devices
            settings.apply {
                webViewCacheSize = 100 * 1024 * 1024 // 100MB cache
                translationUpdateInterval = 1500 // 1.5 seconds
                controlsOpacity = 0.8f
                enableHardwareAcceleration = true
                maxConcurrentTranslations = 3
                useCompressedTextures = false
                reducedAnimations = false
                lowQualityOverlays = false
            }
        }
        
        Log.d(TAG, "Applied optimization settings: $settings")
        return settings
    }
    
    fun optimizeWebView(webView: WebView, settings: OptimizationSettings) {
        val webSettings = webView.settings
        
        // Basic optimizations
        webSettings.cacheMode = WebSettings.LOAD_DEFAULT
        webSettings.setAppCacheMaxSize(settings.webViewCacheSize.toLong())
        webSettings.setAppCacheEnabled(true)
        
        // Performance optimizations for low-end devices
        if (settings.lowQualityOverlays) {
            webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH)
            webSettings.layoutAlgorithm = WebSettings.LayoutAlgorithm.SINGLE_COLUMN
        }
        
        // Hardware acceleration
        if (settings.enableHardwareAcceleration) {
            webView.setLayerType(WebView.LAYER_TYPE_HARDWARE, null)
        } else {
            webView.setLayerType(WebView.LAYER_TYPE_SOFTWARE, null)
        }
        
        // Memory optimizations
        webSettings.setGeolocationEnabled(false)
        webSettings.setNeedInitialFocus(false)
        webSettings.setSaveFormData(false)
        webSettings.setSavePassword(false)
        
        Log.d(TAG, "WebView optimized for device")
    }
    
    private fun isHuaweiY6Prime(): Boolean {
        return Build.MODEL.contains("DUB-LX1", ignoreCase = true) ||
               Build.DEVICE.contains("HWDUB-H", ignoreCase = true) ||
               (Build.MANUFACTURER.equals("HUAWEI", ignoreCase = true) && 
                Build.MODEL.contains("Y6 Prime", ignoreCase = true))
    }
    
    private fun isLowEndDevice(): Boolean {
        // Check RAM (approximate)
        val runtime = Runtime.getRuntime()
        val maxMemory = runtime.maxMemory()
        val maxMemoryMB = maxMemory / (1024 * 1024)
        
        // Check API level
        val isOldAndroid = Build.VERSION.SDK_INT <= TARGET_API_LEVEL
        
        // Check if device has limited RAM
        val isLowRAM = maxMemoryMB < 4096 // Less than 4GB
        
        Log.d(TAG, "Device memory: ${maxMemoryMB}MB, API: ${Build.VERSION.SDK_INT}")
        
        return isOldAndroid || isLowRAM
    }
    
    fun getRecommendedSettings(): Map<String, Any> {
        val settings = optimizeForHuaweiY6Prime()
        
        return mapOf(
            "translation_quality" to if (settings.lowQualityOverlays) "low" else "high",
            "controls_opacity" to settings.controlsOpacity,
            "animation_scale" to if (settings.reducedAnimations) 0.5f else 1.0f,
            "cache_size_mb" to settings.webViewCacheSize / (1024 * 1024),
            "hardware_acceleration" to settings.enableHardwareAcceleration,
            "update_interval_ms" to settings.translationUpdateInterval
        )
    }
    
    data class OptimizationSettings(
        var webViewCacheSize: Int = 100 * 1024 * 1024,
        var translationUpdateInterval: Long = 1500,
        var controlsOpacity: Float = 0.8f,
        var enableHardwareAcceleration: Boolean = true,
        var maxConcurrentTranslations: Int = 3,
        var useCompressedTextures: Boolean = false,
        var reducedAnimations: Boolean = false,
        var lowQualityOverlays: Boolean = false
    )
}

