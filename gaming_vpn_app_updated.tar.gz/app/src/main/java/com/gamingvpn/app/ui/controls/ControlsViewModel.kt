package com.gamingvpn.app.ui.controls

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ControlsViewModel : ViewModel() {

    private val _games = MutableLiveData<List<Game>>().apply {
        value = listOf(
            Game("1", "لعبة القتال", "fps_game", "ic_sword"),
            Game("2", "لعبة السباق", "racing_game", "ic_car"),
            Game("3", "لعبة الرماية", "action_game", "ic_gun")
        )
    }
    val games: LiveData<List<Game>> = _games
    
    private val _selectedGame = MutableLiveData<Game?>().apply {
        value = null
    }
    val selectedGame: LiveData<Game?> = _selectedGame
    
    private val _controlsEnabled = MutableLiveData<Boolean>().apply {
        value = false
    }
    val controlsEnabled: LiveData<Boolean> = _controlsEnabled
    
    fun selectGame(game: Game) {
        _selectedGame.value = game
    }
    
    fun addGame(game: Game) {
        val currentGames = _games.value?.toMutableList() ?: mutableListOf()
        currentGames.add(game)
        _games.value = currentGames
    }
    
    fun removeGame(gameId: String) {
        val currentGames = _games.value?.toMutableList() ?: mutableListOf()
        currentGames.removeAll { it.id == gameId }
        _games.value = currentGames
    }
    
    fun setControlsEnabled(enabled: Boolean) {
        _controlsEnabled.value = enabled
    }
    
    fun updateGameProfile(gameId: String, profile: String) {
        val currentGames = _games.value?.toMutableList() ?: mutableListOf()
        val gameIndex = currentGames.indexOfFirst { it.id == gameId }
        
        if (gameIndex != -1) {
            currentGames[gameIndex] = currentGames[gameIndex].copy(profile = profile)
            _games.value = currentGames
        }
    }
}

