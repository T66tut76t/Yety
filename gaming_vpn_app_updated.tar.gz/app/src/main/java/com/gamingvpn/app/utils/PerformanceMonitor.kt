package com.gamingvpn.app.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import android.util.Log
import kotlinx.coroutines.*

class PerformanceMonitor(private val context: Context) {
    
    companion object {
        private const val TAG = "PerformanceMonitor"
        private const val MONITORING_INTERVAL = 5000L // 5 seconds
    }
    
    private var monitoringJob: Job? = null
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    
    fun startMonitoring() {
        monitoringJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                try {
                    val metrics = collectMetrics()
                    logMetrics(metrics)
                    
                    // Check for performance issues
                    checkPerformanceIssues(metrics)
                    
                    delay(MONITORING_INTERVAL)
                } catch (e: Exception) {
                    Log.e(TAG, "Error during performance monitoring", e)
                }
            }
        }
        
        Log.d(TAG, "Performance monitoring started")
    }
    
    fun stopMonitoring() {
        monitoringJob?.cancel()
        Log.d(TAG, "Performance monitoring stopped")
    }
    
    private fun collectMetrics(): PerformanceMetrics {
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        
        val runtime = Runtime.getRuntime()
        val usedMemory = runtime.totalMemory() - runtime.freeMemory()
        val maxMemory = runtime.maxMemory()
        
        return PerformanceMetrics(
            totalRAM = memoryInfo.totalMem,
            availableRAM = memoryInfo.availMem,
            usedAppMemory = usedMemory,
            maxAppMemory = maxMemory,
            isLowMemory = memoryInfo.lowMemory,
            memoryThreshold = memoryInfo.threshold,
            nativeHeapSize = Debug.getNativeHeapSize(),
            nativeHeapAllocated = Debug.getNativeHeapAllocatedSize(),
            timestamp = System.currentTimeMillis()
        )
    }
    
    private fun logMetrics(metrics: PerformanceMetrics) {
        val totalRAMMB = metrics.totalRAM / (1024 * 1024)
        val availableRAMMB = metrics.availableRAM / (1024 * 1024)
        val usedAppMemoryMB = metrics.usedAppMemory / (1024 * 1024)
        val maxAppMemoryMB = metrics.maxAppMemory / (1024 * 1024)
        
        Log.d(TAG, """
            Performance Metrics:
            - Total RAM: ${totalRAMMB}MB
            - Available RAM: ${availableRAMMB}MB
            - App Memory Used: ${usedAppMemoryMB}MB / ${maxAppMemoryMB}MB
            - Low Memory: ${metrics.isLowMemory}
            - Native Heap: ${metrics.nativeHeapAllocated / (1024 * 1024)}MB
        """.trimIndent())
    }
    
    private fun checkPerformanceIssues(metrics: PerformanceMetrics) {
        // Check memory usage
        val memoryUsagePercent = (metrics.usedAppMemory.toFloat() / metrics.maxAppMemory) * 100
        
        when {
            memoryUsagePercent > 90 -> {
                Log.w(TAG, "Critical memory usage: ${memoryUsagePercent.toInt()}%")
                // Trigger aggressive cleanup
                triggerMemoryCleanup()
            }
            memoryUsagePercent > 75 -> {
                Log.w(TAG, "High memory usage: ${memoryUsagePercent.toInt()}%")
                // Trigger moderate cleanup
                triggerModerateCleanup()
            }
            metrics.isLowMemory -> {
                Log.w(TAG, "System low memory detected")
                triggerMemoryCleanup()
            }
        }
        
        // Check available RAM
        val availableRAMPercent = (metrics.availableRAM.toFloat() / metrics.totalRAM) * 100
        if (availableRAMPercent < 10) {
            Log.w(TAG, "Very low system RAM: ${availableRAMPercent.toInt()}%")
            triggerSystemOptimization()
        }
    }
    
    private fun triggerMemoryCleanup() {
        Log.d(TAG, "Triggering aggressive memory cleanup")
        
        // Force garbage collection
        System.gc()
        
        // Clear caches
        // This would trigger cleanup in other components
    }
    
    private fun triggerModerateCleanup() {
        Log.d(TAG, "Triggering moderate cleanup")
        
        // Suggest garbage collection
        System.gc()
    }
    
    private fun triggerSystemOptimization() {
        Log.d(TAG, "Triggering system optimization")
        
        // Reduce quality settings
        // Disable non-essential features
        // This would communicate with other app components
    }
    
    fun getCurrentMetrics(): PerformanceMetrics {
        return collectMetrics()
    }
    
    fun getOptimizationRecommendations(): List<String> {
        val metrics = collectMetrics()
        val recommendations = mutableListOf<String>()
        
        val memoryUsagePercent = (metrics.usedAppMemory.toFloat() / metrics.maxAppMemory) * 100
        val availableRAMPercent = (metrics.availableRAM.toFloat() / metrics.totalRAM) * 100
        
        if (memoryUsagePercent > 75) {
            recommendations.add("تقليل جودة الترجمة لتوفير الذاكرة")
            recommendations.add("إغلاق التطبيقات الأخرى")
        }
        
        if (availableRAMPercent < 20) {
            recommendations.add("إعادة تشغيل الجهاز لتحرير الذاكرة")
            recommendations.add("تقليل شفافية أزرار التحكم")
        }
        
        if (metrics.isLowMemory) {
            recommendations.add("تفعيل وضع توفير الطاقة")
            recommendations.add("إيقاف الميزات غير الضرورية")
        }
        
        return recommendations
    }
    
    data class PerformanceMetrics(
        val totalRAM: Long,
        val availableRAM: Long,
        val usedAppMemory: Long,
        val maxAppMemory: Long,
        val isLowMemory: Boolean,
        val memoryThreshold: Long,
        val nativeHeapSize: Long,
        val nativeHeapAllocated: Long,
        val timestamp: Long
    )
}

