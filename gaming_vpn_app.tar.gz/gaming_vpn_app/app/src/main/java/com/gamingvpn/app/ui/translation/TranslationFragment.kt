package com.gamingvpn.app.ui.translation

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.gamingvpn.app.databinding.FragmentTranslationBinding
import com.gamingvpn.app.translation.TranslationOverlayService

class TranslationFragment : Fragment() {

    private var _binding: FragmentTranslationBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var translationViewModel: TranslationViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        translationViewModel = ViewModelProvider(this)[TranslationViewModel::class.java]

        _binding = FragmentTranslationBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupUI()
        observeViewModel()

        return root
    }
    
    private fun setupUI() {
        // Translation toggle
        binding.translationToggle.setOnCheckedChangeListener { _, isChecked ->
            translationViewModel.setTranslationEnabled(isChecked)
            
            val intent = Intent(requireContext(), TranslationOverlayService::class.java)
            intent.action = if (isChecked) "ENABLE_TRANSLATION" else "DISABLE_TRANSLATION"
            requireContext().startService(intent)
        }
        
        // Target language selection
        binding.targetLanguageCard.setOnClickListener {
            // Show language selection dialog
            showLanguageSelectionDialog()
        }
        
        // Font size slider
        binding.fontSizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    translationViewModel.setFontSize(progress)
                }
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        
        // Overlay opacity slider
        binding.overlayOpacitySlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    translationViewModel.setOverlayOpacity(progress)
                }
            }
            
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }
    
    private fun observeViewModel() {
        translationViewModel.translationEnabled.observe(viewLifecycleOwner) { enabled ->
            binding.translationToggle.isChecked = enabled
        }
        
        translationViewModel.targetLanguage.observe(viewLifecycleOwner) { language ->
            binding.targetLanguageText.text = language
        }
        
        translationViewModel.fontSize.observe(viewLifecycleOwner) { size ->
            binding.fontSizeSlider.progress = size
        }
        
        translationViewModel.overlayOpacity.observe(viewLifecycleOwner) { opacity ->
            binding.overlayOpacitySlider.progress = opacity
        }
    }
    
    private fun showLanguageSelectionDialog() {
        // In a real implementation, this would show a dialog with language options
        // For now, we'll just toggle between Arabic and English
        val currentLanguage = translationViewModel.targetLanguage.value
        val newLanguage = if (currentLanguage == "العربية") "English" else "العربية"
        translationViewModel.setTargetLanguage(newLanguage)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

