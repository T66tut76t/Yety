package com.gamingvpn.app.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.gamingvpn.app.databinding.FragmentHomeBinding
import com.gamingvpn.app.vpn.VpnService

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var homeViewModel: HomeViewModel
    private var isVpnConnected = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        homeViewModel = ViewModelProvider(this)[HomeViewModel::class.java]

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupUI()
        observeViewModel()

        return root
    }
    
    private fun setupUI() {
        // VPN toggle button
        binding.vpnToggle.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                connectVpn()
            } else {
                disconnectVpn()
            }
        }
        
        // VPN region selection
        binding.vpnRegionCard.setOnClickListener {
            // Navigate to VPN fragment
            // This would be implemented with Navigation Component
        }
        
        // Translation settings
        binding.translationCard.setOnClickListener {
            // Navigate to Translation fragment
        }
        
        // Custom controls
        binding.controlsCard.setOnClickListener {
            // Navigate to Controls fragment
        }
    }
    
    private fun observeViewModel() {
        homeViewModel.vpnStatus.observe(viewLifecycleOwner) { status ->
            binding.vpnStatusText.text = status
        }
        
        homeViewModel.selectedRegion.observe(viewLifecycleOwner) { region ->
            binding.vpnRegionText.text = region
        }
        
        homeViewModel.translationEnabled.observe(viewLifecycleOwner) { enabled ->
            binding.translationStatusText.text = if (enabled) "Enabled" else "Disabled"
        }
    }
    
    private fun connectVpn() {
        val intent = Intent(requireContext(), VpnService::class.java)
        intent.action = "CONNECT"
        intent.putExtra("server_address", homeViewModel.selectedRegion.value ?: "us.example.com")
        requireContext().startService(intent)
        
        isVpnConnected = true
        homeViewModel.setVpnStatus("Connected")
    }
    
    private fun disconnectVpn() {
        val intent = Intent(requireContext(), VpnService::class.java)
        intent.action = "DISCONNECT"
        requireContext().startService(intent)
        
        isVpnConnected = false
        homeViewModel.setVpnStatus("Disconnected")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

