package com.gamingvpn.app.ui.controls

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.gamingvpn.app.R

class GamesAdapter(
    private val onGameClick: (Game) -> Unit
) : ListAdapter<Game, GamesAdapter.GameViewHolder>(GameDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_game, parent, false)
        return GameViewHolder(view)
    }

    override fun onBindViewHolder(holder: GameViewHolder, position: Int) {
        val game = getItem(position)
        holder.bind(game, onGameClick)
    }

    class GameViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val gameIcon: ImageView = itemView.findViewById(R.id.game_icon)
        private val gameName: TextView = itemView.findViewById(R.id.game_name)
        private val gameProfile: TextView = itemView.findViewById(R.id.game_profile)

        fun bind(game: Game, onGameClick: (Game) -> Unit) {
            gameName.text = game.name
            gameProfile.text = when (game.profile) {
                "fps_game" -> "لعبة رماية"
                "racing_game" -> "لعبة سباق"
                "action_game" -> "لعبة أكشن"
                else -> "افتراضي"
            }
            
            // Set game icon based on profile
            val iconResource = when (game.profile) {
                "fps_game" -> R.drawable.ic_gun
                "racing_game" -> R.drawable.ic_car
                "action_game" -> R.drawable.ic_sword
                else -> R.drawable.ic_gamepad
            }
            gameIcon.setImageResource(iconResource)
            
            itemView.setOnClickListener {
                onGameClick(game)
            }
        }
    }

    class GameDiffCallback : DiffUtil.ItemCallback<Game>() {
        override fun areItemsTheSame(oldItem: Game, newItem: Game): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Game, newItem: Game): Boolean {
            return oldItem == newItem
        }
    }
}

