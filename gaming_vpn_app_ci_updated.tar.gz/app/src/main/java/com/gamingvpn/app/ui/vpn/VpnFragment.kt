package com.gamingvpn.app.ui.vpn

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.gamingvpn.app.databinding.FragmentVpnBinding

class VpnFragment : Fragment() {

    private var _binding: FragmentVpnBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var vpnViewModel: VpnViewModel
    private lateinit var regionsAdapter: RegionsAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        vpnViewModel = ViewModelProvider(this)[VpnViewModel::class.java]

        _binding = FragmentVpnBinding.inflate(inflater, container, false)
        val root: View = binding.root

        setupUI()
        observeViewModel()

        return root
    }
    
    private fun setupUI() {
        regionsAdapter = RegionsAdapter { region ->
            vpnViewModel.setSelectedRegion(region)
        }
        
        binding.regionsRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = regionsAdapter
        }
    }
    
    private fun observeViewModel() {
        vpnViewModel.regions.observe(viewLifecycleOwner) { regions ->
            regionsAdapter.submitList(regions)
        }
        
        vpnViewModel.selectedRegion.observe(viewLifecycleOwner) { region ->
            // Update UI to show selected region
            regionsAdapter.notifyDataSetChanged() // To update checkmark
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

