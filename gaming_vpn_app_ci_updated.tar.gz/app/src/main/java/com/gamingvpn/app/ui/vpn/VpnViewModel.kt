package com.gamingvpn.app.ui.vpn

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class VpnViewModel : ViewModel() {

    private val _regions = MutableLiveData<List<String>>().apply {
        value = listOf(
            "United States",
            "Germany",
            "Singapore",
            "United Kingdom",
            "Canada",
            "Australia",
            "Netherlands",
            "Japan"
        )
    }
    val regions: LiveData<List<String>> = _regions
    
    private val _selectedRegion = MutableLiveData<String>().apply {
        value = "United States"
    }
    val selectedRegion: LiveData<String> = _selectedRegion
    
    fun setSelectedRegion(region: String) {
        _selectedRegion.value = region
    }
}

